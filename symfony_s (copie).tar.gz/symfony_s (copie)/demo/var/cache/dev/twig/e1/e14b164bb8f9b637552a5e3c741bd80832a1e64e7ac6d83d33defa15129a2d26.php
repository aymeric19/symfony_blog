<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* blog/show2.html.twig */
class __TwigTemplate_d73e4fb39c4c15513b4462b7bdaef2e5cb2ff1069c8142546197cba1610ba0d3 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blog/show2.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blog/show2.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "blog/show2.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
<article>
        <h2>Titre de test</h2>
        <metadata>ecrit le 06/04/2021 a 19:00 section art</metadata>
        <div class=\"content\">
            <img src=\"https://www.surfsession.com/img/pictures/2018/20180920/thumbnail/1809206335.png\" alt=\"\">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Et, at perferendis aspernatur explicabo fugit possimus.</p>
            <p>Ab, veniam quos repellendus quis vitae officia repudiandae molestias error sunt culpa impedit repellat facilis.</p>
            <hr>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Molestias quod vel quibusdam, laborum doloremque, quisquam neque necessitatibus fuga provident earum accusantium labore. Esse facilis assumenda, facere saepe veniam magni aperiam! Recusandae eveniet libero tempore esse quos nam eius inventore expedita, illo corrupti, ab delectus magnam debitis mollitia sit, consequuntur autem!</p>
            <p>Quas, pariatur fuga itaque facere error at eius similique mollitia, praesentium sed beatae provident delectus asperiores sint inventore veritatis harum obcaecati eligendi eum. Vitae neque enim architecto illo voluptas molestias sit magni tenetur repellendus numquam repellat recusandae, ullam ipsum dicta distinctio animi, expedita aspernatur corporis dignissimos. Maxime qui odit quis.</p>
        </div>
    </article>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "blog/show2.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 4,  58 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}

<article>
        <h2>Titre de test</h2>
        <metadata>ecrit le 06/04/2021 a 19:00 section art</metadata>
        <div class=\"content\">
            <img src=\"https://www.surfsession.com/img/pictures/2018/20180920/thumbnail/1809206335.png\" alt=\"\">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Et, at perferendis aspernatur explicabo fugit possimus.</p>
            <p>Ab, veniam quos repellendus quis vitae officia repudiandae molestias error sunt culpa impedit repellat facilis.</p>
            <hr>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Molestias quod vel quibusdam, laborum doloremque, quisquam neque necessitatibus fuga provident earum accusantium labore. Esse facilis assumenda, facere saepe veniam magni aperiam! Recusandae eveniet libero tempore esse quos nam eius inventore expedita, illo corrupti, ab delectus magnam debitis mollitia sit, consequuntur autem!</p>
            <p>Quas, pariatur fuga itaque facere error at eius similique mollitia, praesentium sed beatae provident delectus asperiores sint inventore veritatis harum obcaecati eligendi eum. Vitae neque enim architecto illo voluptas molestias sit magni tenetur repellendus numquam repellat recusandae, ullam ipsum dicta distinctio animi, expedita aspernatur corporis dignissimos. Maxime qui odit quis.</p>
        </div>
    </article>

{% endblock %}", "blog/show2.html.twig", "/home/megan/Bureau/symfony_s/demo/templates/blog/show2.html.twig");
    }
}
